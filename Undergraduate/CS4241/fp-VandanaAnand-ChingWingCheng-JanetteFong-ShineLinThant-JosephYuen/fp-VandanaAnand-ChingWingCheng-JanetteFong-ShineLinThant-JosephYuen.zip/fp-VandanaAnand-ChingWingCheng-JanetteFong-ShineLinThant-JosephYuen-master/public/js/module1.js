console.log('module1.js')

function hello () {
  console.log('hi from mod1')
}

// Export functions and const
export { hello }
